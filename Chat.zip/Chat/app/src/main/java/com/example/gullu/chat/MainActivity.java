package com.example.gullu.chat;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;





public class MainActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button individual_chat = (Button) findViewById(R.id.indi_chat);
        Button gruop_chat = (Button) findViewById(R.id.group_chat);


        individual_chat.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Login.class);
                startActivityForResult(in, 1);
            }
        });




    }
}